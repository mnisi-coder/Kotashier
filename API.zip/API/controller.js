 
 
 
 var app = angular.module('bookitnow',[]);
        app.controller('myCtrl', function($scope,$http){
        $scope.submit = function() {

            var data ={
                    name   : $scope.name, 
                    email   : $scope.email,
                    roles   : $scope.roles,
                    password: $scope.pswd
                }
            };

            $http.post('/', $scope.data)
            .success(function (data, status, headers, config) {
                    $scope.result = data;
                    console.log("inserted successfully")
                })
                .error(function(data, status, header, config){
                    $scope.result = "Data: " + status;


                });

            $scope.add.push(data);
            $scope.addNewUser = {
					
                    name:"",
                    email:"",
                    roles:"",
                    password:""
					
        };
});